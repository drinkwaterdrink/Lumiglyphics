Standard Visual Novel Audio Pack
=================================
This pack provides standard visual novel background soundtracks and sound effects.

Usage:
1. Place this folder (or point to it) in the Visual Novel Settings -> "Audio & Atmosphere" -> "Audio directory".
2. Click "Scan Audio".
3. The visual planner and stage will automatically select tracks and trigger effects contextually.

Licenses:
- Sound Novel - Tiny Pack: CC-BY-SA 4.0
- First Light Particles: CC0 Public Domain
- Kenney Audio Packs: CC0 1.0 Universal
